# =================================================================
# Script para Criar Arquivos JSON (VERSAO FINAL - PRESERVA UNICODE)
# =================================================================
try {
    Write-Host "Iniciando a criacao de arquivos JSON..." -ForegroundColor White
    Write-Host ""

    $outputFolder = 'jsons_criados'
    $clipboardContent = Get-Clipboard

    if ([string]::IsNullOrWhiteSpace($clipboardContent)) {
        Write-Host "A area de transferencia (clipboard) esta vazia. Copie os JSONs primeiro." -ForegroundColor Yellow
        return
    }

    if (-not (Test-Path -Path $outputFolder)) {
        New-Item -ItemType Directory -Path $outputFolder | Out-Null
        Write-Host "Pasta 'jsons_criados' criada com sucesso." -ForegroundColor Green
    }

    $jsonBlocks = [regex]::Matches($clipboardContent, '(?s)\{.*?\};?')

    if ($jsonBlocks.Count -eq 0) {
        Write-Host "Nenhum bloco JSON valido foi encontrado no clipboard." -ForegroundColor Yellow
        return
    }

    Write-Host "Encontrados $($jsonBlocks.Count) blocos JSON. Processando..." -ForegroundColor Cyan
    Write-Host ""

    foreach ($block in $jsonBlocks) {
        # Esta � a string original, com os \uXXXX intactos
        $originalJsonString = $block.Value.Trim().TrimEnd(';')
        
        # Convertemos para um objeto APENAS para pegar o nome da carta
        $cardObject = $originalJsonString | ConvertFrom-Json -ErrorAction SilentlyContinue

        if (-not $cardObject) {
            Write-Host "AVISO: Um bloco de texto nao pode ser lido como JSON e foi ignorado." -ForegroundColor Yellow
            continue
        }
        
        $cardName = $cardObject.name

        # Geramos o nome do arquivo
        $normalizedName = $cardName.Normalize('FormD')
        $regex = [System.Text.RegularExpressions.Regex]::new('\p{M}')
        $noAccentsName = $regex.Replace($normalizedName, '')
        $finalName = $noAccentsName.Replace('�', 'c').Replace('�', 'C')
        $finalName = $finalName.Replace(' ', '_').Replace(':', '').Replace('(', '').Replace(')', '').Replace(',', '')
        $finalName = $finalName.ToLower()
        $jsonFileName = "$($finalName).json"
        
        $destinationPath = Join-Path -Path $outputFolder -ChildPath $jsonFileName
        
        # --- A GRANDE MUDANCA ESTA AQUI ---
        # Salvamos a STRING ORIGINAL ($originalJsonString) em vez de um JSON reconstruido.
        # Isso preserva os escapes \uXXXX perfeitamente.

        $utf8WithoutBom = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllText($destinationPath, $originalJsonString, $utf8WithoutBom)
        # --- FIM DA MUDANCA ---

        Write-Host ("Arquivo criado: $($jsonFileName)") -ForegroundColor Cyan
    }

    Write-Host ""
    Write-Host "Processo concluido com sucesso!" -ForegroundColor Green

} catch {
    Write-Host ""
    Write-Host "Ocorreu um erro durante a execucao:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
}